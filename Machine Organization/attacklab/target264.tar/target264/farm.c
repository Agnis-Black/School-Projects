/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_317(unsigned x)
{
    return x + 2425378865U;
}

unsigned addval_307(unsigned x)
{
    return x + 2445773128U;
}

void setval_162(unsigned *p)
{
    *p = 3351742792U;
}

unsigned getval_390()
{
    return 3284633928U;
}

unsigned getval_332()
{
    return 2421164191U;
}

unsigned getval_471()
{
    return 2421720294U;
}

void setval_381(unsigned *p)
{
    *p = 2425641168U;
}

void setval_384(unsigned *p)
{
    *p = 3347663004U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_287(unsigned x)
{
    return x + 3380920585U;
}

unsigned addval_329(unsigned x)
{
    return x + 3284797877U;
}

void setval_302(unsigned *p)
{
    *p = 2425408137U;
}

unsigned getval_358()
{
    return 3526937227U;
}

unsigned addval_234(unsigned x)
{
    return x + 3767093309U;
}

unsigned getval_355()
{
    return 3529561737U;
}

unsigned getval_469()
{
    return 3223901833U;
}

unsigned addval_187(unsigned x)
{
    return x + 3234125449U;
}

void setval_346(unsigned *p)
{
    *p = 3380923017U;
}

unsigned addval_328(unsigned x)
{
    return x + 3286272072U;
}

void setval_131(unsigned *p)
{
    *p = 3531134601U;
}

void setval_206(unsigned *p)
{
    *p = 3677929857U;
}

unsigned addval_255(unsigned x)
{
    return x + 2464188744U;
}

void setval_314(unsigned *p)
{
    *p = 3678980745U;
}

unsigned addval_239(unsigned x)
{
    return x + 3286270280U;
}

unsigned addval_362(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_216()
{
    return 3677929865U;
}

void setval_473(unsigned *p)
{
    *p = 2425408009U;
}

unsigned getval_383()
{
    return 3286272328U;
}

unsigned getval_111()
{
    return 3380926121U;
}

unsigned addval_181(unsigned x)
{
    return x + 2428569887U;
}

unsigned getval_264()
{
    return 3527988873U;
}

unsigned addval_363(unsigned x)
{
    return x + 3269495112U;
}

void setval_260(unsigned *p)
{
    *p = 3677929897U;
}

unsigned getval_202()
{
    return 3269495112U;
}

unsigned getval_233()
{
    return 3221277321U;
}

unsigned addval_129(unsigned x)
{
    return x + 3224420745U;
}

unsigned addval_418(unsigned x)
{
    return x + 3234120073U;
}

void setval_374(unsigned *p)
{
    *p = 3682915977U;
}

unsigned getval_335()
{
    return 3676883593U;
}

unsigned getval_306()
{
    return 3531915657U;
}

void setval_378(unsigned *p)
{
    *p = 3674789513U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
